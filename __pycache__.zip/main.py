from fastapi import FastAPI
from database import engine , Base 
from routes  import service_provider 


Base.metadata.create_all(bind=engine)

app = FastAPI()

app.include_router(service_provider.router)